<template>
  <index />
</template>

<script>
import index from "./page/index";

export default {
  components: {
    index,
  },
};
</script>

<style>
</style>
